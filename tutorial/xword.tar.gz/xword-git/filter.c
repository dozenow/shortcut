#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "types.h"
#include "filter.h"

extern answer_t a_answers[MAX_ANSWERS/2];
extern answer_t d_answers[MAX_ANSWERS/2];
extern int a_answer_num, d_answer_num;
extern int num_words[WORDLEN];
extern char* words[WORDLEN][MAX_WORDS];

int find_word (char* word)
{
    int len, min, max, val, w;

    // Find word - use binary search 
    len = strlen(word);
    min = 0;
    max = num_words[len]-1;
    while (max >= min) {
	w = (min+max)/2;
	val = strcmp(words[len][w], word);
	if (val > 0) {
	    max = w-1;
	} else if (val < 0) {
	    min = w+1;
	} else {
	    break;
	}
    }
    if (min > max) {
	printf ("Cannot find input word: %s???\n", word);
	return -1;
    }
    return w;
}

// Build up a filter for all entries in a frequency files.  If an entry appears more than once, we'll just
// use the union of all possible answers, since all lists should really be the same.
int read_freqs (char* filename)
{
    char rc, buf[256];
    char* p, *p2;
    FILE* file; 
    int row, column, i, w;
    answer_t* answer = NULL;

    file = fopen (filename, "r");
    if (file == NULL) {
	fprintf (stderr, "read_freqs cannot open file %s\n", filename);
	return -1;
    }
    
    while (!feof(file)) {
	if (fgets (buf, sizeof(buf), file)) {
	    if ((p = strchr (buf, ',')) != NULL) {
		rc = buf[0];
		*p = '\0';
		row = atoi(buf+1);
		p = p+1;
		p2 = strchr (p, ':');
		*p2 = '\0';
		column = atoi(p);
		//printf ("%c %d %d\n", rc, row, column);
		answer = NULL;
		if (rc == 'A') {
		    for (i = 0; i < a_answer_num; i++) {
			if (a_answers[i].start_row == row && a_answers[i].start_col == column) {
			    answer = &a_answers[i];
			}
		    }
		} else {
		    for (i = 0; i < d_answer_num; i++) {
			if (d_answers[i].start_row == row && d_answers[i].start_col == column) {
			    answer = &d_answers[i];
			}
		    }
		}
		if (answer) {
		    if (answer->filter == NULL) { 
			answer->filter = calloc(1, sizeof(vector_t));
			if (answer->filter == NULL) {
			    fprintf (stderr, "read_freqs unable to calloc vector - cannot filter\n");
			    answer = NULL;
			}
		    }
		} else {
		    fprintf (stderr, "Answer %c%d,%d not found - cannot filter\n", rc, row, column);
		}
	    } else if ((p = strchr(buf, ':')) != NULL) {
		*p = '\0';
		//printf ("\t%s\n", buf);
		if (answer) {
		    w = find_word (buf);
		    if (w >= 0) {
			SET_CONSTRAINT(answer->filter,w);
			answer->filter->bits_set++;
		    }
		}
	    }
	} 
    }
    fclose (file);
    return 0;
}


