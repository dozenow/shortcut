#!/usr/bin/python

import datetime
import sys
import os
import subprocess
import popen2

days = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

p = subprocess.Popen (["grep", "^" + sys.argv[1] + " ", "puzzles/puzzle.db"], stdout=subprocess.PIPE)
lines = p.stdout.read().split("\n")
for line in lines:
    tokens = line.split()
    if len(tokens) > 1:
        mstr = tokens[1][0:3]
        if (mstr == "Jan"):
            month = 1
        elif (mstr == "Feb"):
            month = 2
        elif (mstr == "Mar"):
            month = 3
        elif (mstr == "Apr"):
            month = 4
        elif (mstr == "May"):
            month = 5
        elif (mstr == "Jun"):
            month = 6
        elif (mstr == "Jul"):
            month = 7
        elif (mstr == "Aug"):
            month = 8
        elif (mstr == "Sep"):
            month = 9
        elif (mstr == "Oct"):
            month = 10
        elif (mstr == "Nov"):
            month = 11
        elif (mstr == "Dec"):
            month = 12
        else:
            print "oops:" + mstr
        day = int(tokens[1][3:5])
        year = int(tokens[1][5:7]) + 2000
        d = datetime.date(year, month, day)
        print days[d.weekday()], line

