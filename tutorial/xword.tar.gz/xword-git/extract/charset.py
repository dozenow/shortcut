#!/usr/bin/python

import sys

page = open("wikitest.htm","r").read()
len = page.__len__()
i = 0
while (i < len):
    if (ord(page[i]) == 195):
        i = i + 1
        if (ord(page[i]) == 129):
            sys.stdout.write("A")
        elif (ord(page[i]) == 137):
            sys.stdout.write("E")
        elif (ord(page[i]) == 144):
            sys.stdout.write("D")
        elif (ord(page[i]) == 147):
            sys.stdout.write("O")
        elif (ord(page[i]) == 152):
            sys.stdout.write("O")
        elif (ord(page[i]) == 160):
            sys.stdout.write("a")
        elif (ord(page[i]) == 161):
            sys.stdout.write("a")
        elif (ord(page[i]) == 164):
            sys.stdout.write("a")
        elif (ord(page[i]) == 167):
            sys.stdout.write("c")
        elif (ord(page[i]) == 168):
            sys.stdout.write("e")
        elif (ord(page[i]) == 169):
            sys.stdout.write("e")
        elif (ord(page[i]) == 170):
            sys.stdout.write("e")
        elif (ord(page[i]) == 173):
            sys.stdout.write("i")
        elif (ord(page[i]) == 177):
            sys.stdout.write("n")
        elif (ord(page[i]) == 179):
            sys.stdout.write("o")
        elif (ord(page[i]) == 182):
            sys.stdout.write("oe")
        elif (ord(page[i]) == 184):
            sys.stdout.write("o")
        elif (ord(page[i]) == 186):
            sys.stdout.write("u")
        elif (ord(page[i]) == 188):
            sys.stdout.write("u")
        elif (ord(page[i]) == 189):
            sys.stdout.write("y")
        else:
            sys.stderr.write("char 195/%d not supported\n"%ord(page[i]))
            die
        i = i + 1
    elif ord(page[i]) == 196:
        i = i + 1
        if (ord(page[i]) == 135):
            sys.stdout.write("c")
        elif (ord(page[i]) == 141):
            sys.stdout.write("c")
        elif (ord(page[i]) == 153):
            sys.stdout.write("e")
        else:
            sys.stderr.write("char 196/%d not supported\n"%ord(page[i]))
            die
        i = i + 1
    elif ord(page[i]) == 197:
        i = i + 1
        if (ord(page[i]) == 130):
            sys.stdout.write("l")
        elif (ord(page[i]) == 140):
            sys.stdout.write("O")
        elif (ord(page[i]) == 141):
            sys.stdout.write("o")
        elif (ord(page[i]) == 190):
            sys.stdout.write("z")
        else:
            sys.stderr.write("char 197/%d not supported\n"%ord(page[i]))
            die
        i = i + 1
    else:
        sys.stdout.write(page[i])
        i = i + 1

