#!/usr/bin/python

import urllib2
import re
import random
import time
import sys

def getgooglelinks(search, name):
    headers = {'User-agent':'Mozilla/11.0'}
    req = urllib2.Request('http://www.google.com/search?q=\"' + search + '\"',None,headers)
    site = urllib2.urlopen(req)
    data = site.read()
    site.close()

    m = re.search("About (.*?) results", data)
    if m:
        results = m.group(1)
        results = re.sub(',', '', results)
        number = int(results)
        print name, ":", number
        sys.stdout.flush()
    else:
        print data
        die

fh = open ("names", "r")
for name in fh:
    name = name.strip()
    search = re.sub(' ','+', name)
    search = search.lower()
    getgooglelinks(search, name)
    sleepdur = random.randint(30,90)
    time.sleep(sleepdur)

