#!/usr/bin/python

import urllib2
import re;
import sys;

headers = {'User-agent':'Mozilla/11.0'}
req = urllib2.Request("http://www.wikipedia.com/wiki/" + sys.argv[1])
site = urllib2.urlopen(req)
data = site.read()
site.close()

#cells = re.findall ("<td>.*?</td>", data, re.DOTALL)
#for cell in cells:
names = re.findall ("<a.*?wiki.*?>(.*?)<\/a>", data)
for name in names:
    if name and name[0] == "<": 
        continue
    name = name.upper()
    name = name.replace("&AMP;", "AND")
    name = name.replace("\xc3\xa9", "E")
    name = name.replace("\xc3\xa9", "E")
    name = name.replace("\xc3\x80", "A")
    name = name.replace("\xc3\x81", "A")
    name = name.replace("\xc3\x82", "A")
    name = name.replace("\xc3\x83", "A")
    name = name.replace("\xc3\x84", "A")
    name = name.replace("\xc3\x85", "A")
    name = name.replace("\xc3\x91", "n")
    name = name.replace("\xc3\xa0", "a")
    name = name.replace("\xc3\xa1", "a")
    name = name.replace("\xc3\xa2", "a")
    name = name.replace("\xc3\xa3", "a")
    name = name.replace("\xc3\xa4", "a")
    name = name.replace("\xc3\xa5", "a")
    name = name.replace("\xc3\xa8", "e")
    name = name.replace("\xc3\xa9", "e")
    name = name.replace("\xc3\xaa", "e")
    name = name.replace("\xc3\xab", "e")
    name = name.replace("\xc3\xac", "i")
    name = name.replace("\xc3\xad", "i")
    name = name.replace("\xc3\xae", "i")
    name = name.replace("\xc3\xaf", "i")
    name = name.replace("\xc3\xb1", "n")
    name = name.replace("\xc3\xb2", "o")
    name = name.replace("\xc3\xb3", "o")
    name = name.replace("\xc3\xb4", "o")
    name = name.replace("\xc3\xb5", "o")
    name = name.replace("\xc3\xb6", "o")
    name = name.replace("\xc3\xb8", "o")
    name = name.replace("\xc3\xb9", "u")
    name = name.replace("\xc3\xba", "u")
    name = name.replace("\xc3\xbb", "u")
    name = name.replace("\xc3\xbc", "u")
    print name
