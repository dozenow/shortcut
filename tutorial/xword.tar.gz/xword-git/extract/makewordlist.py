#!/usr/bin/python

import re

def decr(value):
    if (value == 50):
        return 40
    elif (value == 40):
        return 30
    else:
        return value-5
    
def add_name(name, value, note):
    if (len(name) > 3):
        print "%s;%d %s"%(name, value, note)
    
fh = open("nobelcounts.all", "r")
for line in fh:
    (name,pages) = line.split(":")
    pages = int(pages)
    if (pages > 1000000):
        value = 50
    elif (pages > 500000):
        value = 40
    elif (pages > 100000):
        value = 30
    else:
        value = 25
    name = re.sub('\'','',name)
    name = re.sub('-','',name)
    name = re.sub('\.','',name)
    names = name.split()
    if (len(names) == 1):
        fullname = names[0]
    elif (len(names) == 2):
        add_name(names[0], value, "C")
        add_name(names[1], value, "L")
        add_name(names[0]+names[1], value, "N")
    elif (len(names) == 3):
        if len(names[1]) == 1:
            if len(names[0]) == 1:
                add_name(names[2], value, "L")
            else:
                add_name(names[0], value, "C")
                add_name(names[2], value, "L")
                add_name(names[0]+names[2], value, "N")
        elif (names[1] == "VON"):
            add_name(names[0], value, "C")
            add_name(names[2], decr(value), "L")
            add_name(names[1]+names[2], value, "L")
        else:
            add_name(names[0], value, "C")
            add_name(names[1], decr(value), "M")
            add_name(names[2], value, "L")
            add_name(names[0]+names[2], value, "N")
        add_name(names[0]+names[1]+names[2], value, "N")
    elif (len(names) == 4):
        if (names[2] == "VON"):
            add_name(names[0], value, "C")
            add_name(names[1], decr(value), "M")
            add_name(names[2]+names[3], value, "L")
            add_name(names[3], value, "L")
            add_name(names[0]+names[2]+names[3], value, "N")
        add_name(names[0]+names[1]+names[2]+names[3], value, "N")
    elif (len(names) == 5):
        if (names[2] == "VAN" and names[3] == "T"):
            add_name(names[0], value, "C")
            add_name(names[1], decr(value), "M")
            add_name(names[2]+names[3]+names[4], value, "L")
            add_name(names[4], decr(value), "L")
        add_name(names[0]+names[1]+names[2]+names[3]+names[4], value, "N")
    else:
        print names
        
    print        
        
            
            
    
