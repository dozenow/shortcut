#!/usr/bin/python

import urllib2
import re;

headers = {'User-agent':'Mozilla/11.0'}
req = urllib2.Request("http://www.phrases.net/phrases/Z/99999")
site = urllib2.urlopen(req)
data = site.read()
site.close()

names = re.findall ("<a.*?phrase.*?>(.*?)<\/a>", data)
for name in names:
    if name and name[0] == "<": 
        continue
    name = name.upper()
    print name
