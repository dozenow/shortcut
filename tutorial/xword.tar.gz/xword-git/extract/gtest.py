#!/usr/bin/python

import re

data = open("out","r").read()
m = re.search("About (.*?) results", data)
if m:
    results = m.group(1)
    results = re.sub(',', '', results)
    number = int(results)
    print number
