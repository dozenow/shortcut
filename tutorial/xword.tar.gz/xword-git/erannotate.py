#!/usr/bin/python
import sys;
import re;
import os;
import urllib2

dict = {};
fh = open ("puzzles/wordfreq", "r");
for line in fh:
    (word, freq) = line.split()
    dict[word] = int(freq);
fh.close()

    
words = {};
fh = open ("wordlists/master.txt", "r");
for line in fh:
    tokens = line.split()
    (word,value) = tokens[0].split(";")
    if word in words:
        print line, "is duplicate"
    value = int(value)
    if len(tokens) == 2:
        note = tokens[1]
    else:
        note = ""
    if (value >= 50 and note != "" and note != "+"):
        print word, value, note
    if (value < 50 and note == "+"):
        print word, value, note
    words[word] = (value,note)
fh.close()

def getgooglelinks(search):
    try:
        headers = {'User-agent':'Mozilla/11.0'}
        req = urllib2.Request('http://www.google.com/search?q=\"' + search + '\"',None,headers)
        site = urllib2.urlopen(req)
        data = site.read()
        site.close()

        m = re.search("About (.*?) results", data)
        if m:
            results = m.group(1)
            results = re.sub(',', '', results)
            number = int(results)
            print search, ":", number
        else:
            print data
    except urllib2.HTTPError:
        print "Too much Google?"

def doword (word,count):
    done = False;
    while not done:
        print "%s %s"%(word,count)
        s = raw_input ("> ");
        s.strip();
        if (s == "q" or s == "Q"):
            done = True;
            return 1;
        elif (s == "s" or s == "S"):
            os.system ("grep \"^" + word + " \" puzzles/puzzle.db");
            continue;
        elif (s == "d" or s == "D"):
            del words[word];
            done = True;
        elif (s == "50"):
            words[word] = (50,"+");
            done = True;
        elif (s[:2] == "V "):
            tokens = s.split()
            if (len(tokens) == 2):
                fword = tokens[1].strip()
                if (fword in words):
                    (value,note) = words[fword]
                    print fword, "has value", value, note
                else:
                    print fword, "not found"
            else:
                print "syntax error"
            continue;
        else:
            tok = s.split(" ");
            if (len(tok) != 2):
                print "syntax error: bad number of tokens"
                continue;
            else:
                try:
                    val = int(tok[0]);
                except ValueError:
                    val = 0
                if (val == 0 or val >= 50):
                    print "syntax error: bad number"
                    continue;
                else:
                    words[word] = (val,tok[1])
                    done = True;
        return 0;

exit = False;            
for k in sorted(words.keys()):
    (value,note) = words[k]
    if not note:
        if k[-3:] == "IER":
            sing = k[0:-3] + "Y"
            eing = k[0:-3] + "IEST"
            if sing in words and eing in words:
                (svalue,snote) = words[sing]
                print sing, svalue, snote
                getgooglelinks(k)
                getgooglelinks(eing)
                value = int(value);
                if k in dict:
                    count = dict[k]
                else:
                    count = 0
                if (doword (k,count)):
                    break;
                if eing in dict:
                    count = dict[eing]
                else:
                    count = 0
                if (doword (eing,count)):
                    break;
        elif k[-2:] == "ER":
            sing = k[0:-2]
            eing = k[0:-2] + "EST"
            if sing in words and eing in words:
                (svalue,snote) = words[sing]
                print sing, svalue, snote
                getgooglelinks(k)
                getgooglelinks(eing)
                value = int(value);
                if k in dict:
                    count = dict[k]
                else:
                    count = 0
                if (doword (k,count)):
                    break;
                if eing in dict:
                    count = dict[eing]
                else:
                    count = 0
                if (doword (eing,count)):
                    break;
            else:
                sing = k[0:-1]
                if sing in words and eing in words:
                    (svalue,snote) = words[sing]
                    print sing, svalue, snote
                    getgooglelinks(k)
                    getgooglelinks(eing)
                    value = int(value);
                    if k in dict:
                        count = dict[k]
                    else:
                        count = 0
                    if (doword (k,count)):
                        break;
                    if eing in dict:
                        count = dict[eing]
                    else:
                        count = 0
                    if (doword (eing,count)):
                        break;
        elif k[-4:] == "IEST":
            sing = k[0:-4] + "Y"
            ring = k[0:-3] + "ER"
            if sing in words and ring in words:
                (svalue,snote) = words[sing]
                (rvalue,rnote) = words[ring]
                print sing, svalue, snote
                print ring, rvalue, rnote
                getgooglelinks(ring)
                getgooglelinks(k)
                value = int(value);
                if k in dict:
                    count = dict[k]
                else:
                    count = 0
                if (doword (k,count)):
                    break;
        elif k[-5:] == "MMEST":
            sing = k[0:-4] 
            ring = k[0:-3] + "ER"
            if sing in words and ring in words:
                (svalue,snote) = words[sing]
                (rvalue,rnote) = words[ring]
                print sing, svalue, snote
                print ring, rvalue, rnote
                value = int(value);
                if k in dict:
                    count = dict[k]
                else:
                    count = 0
                if (doword (k,count)):
                    break;
        elif k[-3:] == "EST":
            sing = k[0:-3]
            ring = k[0:-3] + "ER"
            if sing in words and ring in words:
                (svalue,snote) = words[sing]
                (rvalue,rnote) = words[ring]
                print sing, svalue, snote
                print ring, rvalue, rnote
                getgooglelinks(ring)
                getgooglelinks(k)
                value = int(value);
                if k in dict:
                    count = dict[k]
                else:
                    count = 0
                if (doword (k,count)):
                    break;
            else:
                sing = k[0:-2]
                if sing in words and ring in words:
                    (svalue,snote) = words[sing]
                    (rvalue,rnote) = words[ring]
                    print sing, svalue, snote
                    print ring, rvalue, rnote
                    getgooglelinks(ring)
                    getgooglelinks(k)
                    value = int(value);
                    if k in dict:
                        count = dict[k]
                    else:
                        count = 0
                    if (doword (k,count)):
                        break;
fh.close()

outfh = open("/tmp/master.txt","w")
sys.stdout = outfh
for k in sorted(words.keys()):
    (value,note) = words[k]
    if note:
        print ("%s;%d %s"%(k,value,note));
    else:
        print ("%s;%d"%(k,value));
        
outfh.close()

