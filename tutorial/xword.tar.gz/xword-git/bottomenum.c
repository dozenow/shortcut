#include <stdio.h>
#include <stdlib.h>

int main (int argc, char* argv[])
{
  int a[15], i, j, run, count = 0;
  FILE* fp;
  char buf[80];
  char str1[16], str2[16];

  for (i = 0; i < 1<<15; i++) {
    run = 0;
    for (j = 0; j < 15; j++) {
      a[j] = (i>>j)%2;
      if (a[j]) {
	run = run + 1;
      } else {
	if (run == 1 || run == 2) break; // Illegal
	run = 0;
      }
    }
    if (run == 1 || run == 2) continue; // Illegal

    sprintf (buf, "bottom_boards/board.%d", count++);
    fp = fopen (buf, "w");
    if (!fp) {
      perror ("fopen");
      exit (1);
    }
    fprintf (fp, "15 15\n");
    fprintf (fp, "xxxxxxxxxxxxxxx\n");
    fprintf (fp, "xxxxxxxxxxxxxxx\n");
    fprintf (fp, "xxxxxxxxxxxxxxx\n");
    fprintf (fp, "xxxxxxxxxxxxxxx\n");
    fprintf (fp, "xxxxxxxxxxxxxxx\n");
    fprintf (fp, "xxxxxxxxxxxxxxx\n");
    fprintf (fp, "xxxxxxxxxxxxxxx\n");
    fprintf (fp, "xxxxxxxxxxxxxxx\n");
    fprintf (fp, "xxxxxxxxxxxxxxx\n");
    for (j = 0; j < 15; j++) {
      if (a[j]) {
	str1[14-j] = '@';
	str2[14-j] = '_';
      } else {
	str1[14-j] = 'x';
	str2[14-j] = '@';
      }
    }
    str1[15] = '\0';
    str2[15] = '\0';
    fprintf (fp, "%s\n", str1);
    fprintf (fp, "%s\n", str2);
    fprintf (fp, "_______________\n");
    fprintf (fp, "bbbbbbbbbbbbbbb\n");
    fprintf (fp, "bbbbbbbbbbbbbbb\n");
    fprintf (fp, "bbbbbbbbbbbbbbb\n");

    fclose (fp);
  }
  return 0;
}
