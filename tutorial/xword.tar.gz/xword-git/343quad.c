#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <semaphore.h>
#include <pthread.h>
#include <assert.h>

#define CONCURRENCY 8
#define INCR 100
#define MIN_VALUE 25
#define T 15

struct node {
  int len;
  int i;
  struct node* next;
} node;

char tseqs[32*32*32];
struct node* dseqs[32*32*32*32];

pthread_mutex_t stdout_lock = PTHREAD_MUTEX_INITIALIZER;
sem_t sem;
char spanners[10000][16];
int scnt = 0;

struct vars {
  int begin_at;
  int end_at;
};

static int check_match (int c1, int c2, int* pndx)
{
    struct node* tmp;
    char match[8*17];

    memset (match, 0, sizeof(match));
    for (tmp = dseqs[pndx[c1]]; tmp; tmp = tmp->next) {
	match[tmp->len*8 + tmp->i] = 1;
    }
    for (tmp = dseqs[pndx[c2]]; tmp; tmp = tmp->next) {
	if (match[tmp->len*8 + (tmp->len-4)-tmp->i]) return 1;
    }
    
    return 0;
}

static int check_ver (int c1, int* pndx)
{
    struct node* tmp;

    for (tmp = dseqs[pndx[c1]]; tmp; tmp = tmp->next) {
	if (tmp->len == 4 && tmp->i == 0) return 1;
	if (tmp->len == 6 && tmp->i == 1) return 1;
	if (tmp->len == 8 && tmp->i == 2) return 1;
	if (tmp->len == 10 && tmp->i == 3) return 1;
	if (tmp->len == 12 && tmp->i == 4) return 1;
	if (tmp->len == 14 && tmp->i == 5) return 1;
	if (tmp->len == 16 && tmp->i == 6) return 1;
    }
    
    return 0;
}

static int print_ver (int c1, struct node* list1, int* pndx)
{
    struct node* tmp;
    struct node* nnode;

    for (tmp = dseqs[pndx[c1]]; tmp; tmp = tmp->next) {
	if (tmp->len == 4 && tmp->i == 0) {
	    //printf ("V <%d> match len 4 i 0\n", c1);
	    nnode = malloc(sizeof(struct node));
	    if (nnode == NULL) {
		fprintf (stderr, "Cannot allocate node\n");
		exit (1);
	    }
	    nnode->len = 4;
	    nnode->i = 0;
	    nnode->next = list1->next;
	    list1->next = nnode;
	}
	if (tmp->len == 6 && tmp->i == 1) {
	    //printf ("V <%d> match len 6 i 1\n", c1);
	    nnode = malloc(sizeof(struct node));
	    if (nnode == NULL) {
		fprintf (stderr, "Cannot allocate node\n");
		exit (1);
	    }
	    nnode->len = 6;
	    nnode->i = 1;
	    nnode->next = list1->next;
	    list1->next = nnode;
	}
	if (tmp->len == 8 && tmp->i == 2) {
	    //printf ("V <%d> match len 8 i 2\n", c1);
	    nnode = malloc(sizeof(struct node));
	    if (nnode == NULL) {
		fprintf (stderr, "Cannot allocate node\n");
		exit (1);
	    }
	    nnode->len = 8;
	    nnode->i = 2;
	    nnode->next = list1->next;
	    list1->next = nnode;
	}
	if (tmp->len == 10 && tmp->i == 3) {
	    //printf ("V <%d> match len 10 i 3\n", c1);
	    nnode = malloc(sizeof(struct node));
	    if (nnode == NULL) {
		fprintf (stderr, "Cannot allocate node\n");
		exit (1);
	    }
	    nnode->len = 10;
	    nnode->i = 3;
	    nnode->next = list1->next;
	    list1->next = nnode;
	}
	if (tmp->len == 12 && tmp->i == 4) {
	    //printf ("V <%d> match len 12 i 4\n", c1);
	    nnode = malloc(sizeof(struct node));
	    if (nnode == NULL) {
		fprintf (stderr, "Cannot allocate node\n");
		exit (1);
	    }
	    nnode->len = 12;
	    nnode->i = 4;
	    nnode->next = list1->next;
	    list1->next = nnode;
	}
	if (tmp->len == 14 && tmp->i == 5) {
	    //printf ("V <%d> match len 15 i 5\n", c1);
	    nnode = malloc(sizeof(struct node));
	    if (nnode == NULL) {
		fprintf (stderr, "Cannot allocate node\n");
		exit (1);
	    }
	    nnode->len = 14;
	    nnode->i = 5;
	    nnode->next = list1->next;
	    list1->next = nnode;
	}
	if (tmp->len == 16 && tmp->i == 6) {
	    //printf ("V <%d> match len 16 i 6\n", c1);
	    nnode = malloc(sizeof(struct node));
	    if (nnode == NULL) {
		fprintf (stderr, "Cannot allocate node\n");
		exit (1);
	    }
	    nnode->len = 16;
	    nnode->i = 6;
	    nnode->next = list1->next;
	    list1->next = nnode;
	}
    }
    
    return 0;
}

static int print_match (int c1, int c2, struct node* list1, int* pndx)
{
    struct node* tmp;
    char match[8*17];
    struct node* nnode;

    memset (match, 0, sizeof(match));
    for (tmp = dseqs[pndx[c1]]; tmp; tmp = tmp->next) {
	match[tmp->len*8 + tmp->i] = 1;
    }
    for (tmp = dseqs[pndx[c2]]; tmp; tmp = tmp->next) {
	if (match[tmp->len*8 + (tmp->len-4)-tmp->i]) {
	  //printf ("<%d,%d> match len %d i %d i %d\n", c1, c2, tmp->len, (tmp->len-4)-tmp->i, tmp->i);

	    nnode = malloc(sizeof(struct node));
	    if (nnode == NULL) {
		fprintf (stderr, "Cannot allocate node\n");
		exit (1);
	    }
	    nnode->len = tmp->len;
	    nnode->i = (tmp->len-4)-tmp->i;
	    nnode->next = list1->next;
	    list1->next = nnode;
	}
    }
    
    return 0;
}

int 
isblock (int y, int x, char grid[16][15])
{
    return (grid[y][x] == '@');
}

int
block (int y, int x, char grid[16][15])
{
    if (y == -1 || y == 16) return 0; // OK to put a block "on the edge"
    if (x == -1 || x == 15) return 0;

    if (isblock(y,x,grid)) return 0;

    //printf ("block at <%d,%d>\n", y, x);

    if (grid[y][x] != '_') {
	grid[y][x] = '@';
    } else {
	return -1;
    }

    // Check left
    if (x == 1) {
	if (block (y, 0, grid) < 0) return -1;
    } else if (x == 2) {
	if (block (y, 1, grid) < 0) return -1;
	if (block (y, 0, grid) < 0) return -1;
    } else if (x != 0) {
	if (isblock(y,x-2,grid)) {
	    if (block (y, x-1, grid) < 0) return -1;
	}
	if (isblock(y,x-3,grid)) {
	    if (block (y, x-1, grid) < 0) return -1;
	    if (block (y, x-2, grid) < 0) return -1;
	}
    }

    // Check right
    if (x == 13) {
	if (block (y, 14, grid) < 0) return -1;
    } else if (x == 12) {
	if (block (y, 13, grid) < 0) return -1;
	if (block (y, 14, grid) < 0) return -1;
    } else if (x != 14) {
	if (isblock(y,x+2,grid)) {
	    if (block (y, x+1, grid) < 0) return -1;
	}
	if (isblock(y,x+3,grid)) {
	    if (block (y, x+1, grid) < 0) return -1;
	    if (block (y, x+2, grid) < 0) return -1;
	}
    }

    // Check top
    if (y == 1) {
	if (block (0, x, grid) < 0) return -1;
    } else if (y == 2) {
	if (block (1, x, grid) < 0) return -1;
	if (block (0, x, grid) < 0) return -1;
    } else if (y != 0) {
	if (isblock(y-2,x, grid)) {
	    if (block (y-1, x, grid) < 0) return -1;
	}
	if (isblock(y-3,x,grid)) {
	    if (block (y-1, x, grid) < 0) return -1;
	    if (block (y-2, x, grid) < 0) return -1;
	}
    }
	
    // Check bottom
    if (y == 14) {
	if (block (15, x, grid) < 0) return -1;
    } else if (y == 13) {
	if (block (14, x, grid) < 0) return -1;
	if (block (15, x, grid) < 0) return -1;
    } else if (y != 15) {
	if (isblock(y+2,x,grid)) {
	    if (block (y+1, x, grid) < 0) return -1;
	}
	if (isblock(y+3,x,grid)) {
	    if (block (y+1, x, grid) < 0) return -1;
	    if (block (y+2, x, grid) < 0) return -1;
	}
    }

    // Symmetry
    return block (15-y, 14-x, grid);
}

int 
isopensquare (int y, int x, char grid[16][15])
{
    return (grid[y][x] == '_');
}


int
opensquare (int y, int x, char grid[16][15])
{
    assert (x >= 0 && y >= 0 && x < 15 && y < 16);
    if (isopensquare(y,x,grid)) return 0;

    if (grid[y][x] != '@') {
	grid[y][x] = '_';
    } else {
	return -1;
    }
    
    // Symmetry
    return opensquare (15-y, 14-x, grid);
}

int placer(int x, int len, int i, char grid[16][15])
{
    int j;

    assert (i >= 0);

    if (block (5 - i, x, grid) < 0) return -1;
    for (j = 5-i+1; j < 6; j++) 
	if (opensquare (j,x, grid) < 0) return -1;
    if (block (6 + len - i, x, grid) < 0) return -1;
    for (j = 10; j < 6 + len - i; j++) 
	if (opensquare (j,x, grid) < 0) return -1;
    return 0;
}

static void 
free_list (struct node* tmp0)
{
    struct node* tmp;
    
    while (tmp0) {
	tmp = tmp0;
	tmp0 = tmp0->next;
	free (tmp);
    }
}

void* do_it (void* p)
{
    struct vars* v = (struct vars *) p;
    int c, i, j, k, l, t;
    int ndx1[15], ndx2[15], ndx3[15], ndx4[15];
    struct node l0, l1, l2, l3, l4, l5, l6, l7;
    char grid[16][15];
    int gi, gj, blocks;
    struct node *tmp0, *tmp1, *tmp2, *tmp3, *tmp4, *tmp5, *tmp6, *tmp7;

    for (i = v->begin_at; i < v->end_at; i++) {
	for (t = 0; t < T; t++) ndx1[t] = spanners[i][t]-'A';
	for (j = 0; j < scnt; j++) {
	    for (t = 0; t < T; t++) ndx2[t] = ndx1[t] + ((spanners[j][t]-'A') << 5);
	    for (k = 0; k < scnt; k++) {
		for (t = 0; t < T; t++) {
		    ndx3[t] = ndx2[t] + ((spanners[k][t]-'A') << 10);
		    if (!tseqs[ndx3[t]]) break;
		}
		if (t == T) {
		    for (l = 0; l < scnt; l++) {
			for (t = 0; t < T; t++) {
			    ndx4[t] = ndx3[t] + ((spanners[l][t]-'A') << 15);
			    if (!dseqs[ndx4[t]]) break;
			}
			if (t == T) {
			    if (check_match(0,14,ndx4) && check_match(1,13,ndx4) && check_match(2,12,ndx4) && 
				check_match(3,11,ndx4) && check_match(4,10,ndx4) && check_match(5,9,ndx4) && 
				check_match(6,8,ndx4) && check_ver(7,ndx4)) {
			      //printf ("%15s %15s %15s %15s\n", spanners[i], spanners[j], spanners[k], spanners[l]);
				l0.next = NULL; 
				print_match (0,14,&l0,ndx4);
				l1.next = NULL;
				print_match (1,13,&l1,ndx4);
				l2.next = NULL;
				print_match (2,12,&l2,ndx4);
				l3.next = NULL;
				print_match (3,11,&l3,ndx4);
				l4.next = NULL;
				print_match (4,10,&l4,ndx4);
				l5.next = NULL;
				print_match (5,9,&l5,ndx4);
				l6.next = NULL;
				print_match (6,8,&l6,ndx4);
				l7.next = NULL;
				print_ver (7, &l7,ndx4);
				for (tmp0 = l0.next; tmp0; tmp0 = tmp0->next) {
				    for (tmp1 = l1.next; tmp1; tmp1 = tmp1->next) {
					for (tmp2 = l2.next; tmp2; tmp2 = tmp2->next) {
					    for (tmp3 = l3.next; tmp3; tmp3 = tmp3->next) {
						for (tmp4 = l4.next; tmp4; tmp4 = tmp4->next) {
						    for (tmp5 = l5.next; tmp5; tmp5 = tmp5->next) {
							for (tmp6 = l6.next; tmp6; tmp6 = tmp6->next) {
							    for (tmp7 = l7.next; tmp7; tmp7 = tmp7->next) {
								for (gi = 0; gi < 16; gi++) {
								    for (gj = 0; gj < 15; gj++) {
									grid[gi][gj] = 'x';
								    }
								}
								for (c = 0; c < 15; c++) {
								    grid[6][c] = spanners[i][c];
								    grid[7][c] = spanners[j][c];
								    grid[8][c] = spanners[k][c];
								    grid[9][c] = spanners[l][c];
								}
								if (placer (0, tmp0->len, tmp0->i, grid) == 0 &&
								    placer (1, tmp1->len, tmp1->i, grid) == 0 &&
								    placer (2, tmp2->len, tmp2->i, grid) == 0 &&
								    placer (3, tmp3->len, tmp3->i, grid) == 0 &&
								    placer (4, tmp4->len, tmp4->i, grid) == 0 &&
								    placer (5, tmp5->len, tmp5->i, grid) == 0 &&
								    placer (6, tmp6->len, tmp6->i, grid) == 0 &&
								    placer (7, tmp7->len, tmp7->i, grid) == 0) {

								    blocks = 0;
								    for (gi = 0; gi < 16; gi++) {
									for (gj = 0; gj < 15; gj++) {
									    if (grid[gi][gj] == '@') blocks++;
									}
								    }
								    if (blocks < 40 ) {
									pthread_mutex_lock(&stdout_lock);
									printf ("16 15\n");
									for (gi = 0; gi < 16; gi++) {
									    for (gj = 0; gj < 15; gj++) {
										printf ("%c", grid[gi][gj]);
									    }
									    printf ("\n");
									}
									printf ("blocks: %d\n", blocks);
									fflush (stdout);
									pthread_mutex_unlock(&stdout_lock);
								    }
								}
							    }
							}
						    }
						}
					    }
					}
				    }
				}
				free_list(l0.next);
				free_list(l1.next);
				free_list(l2.next);
				free_list(l3.next);
				free_list(l4.next);
				free_list(l5.next);
				free_list(l6.next);
				free_list(l7.next);
			    }
			}
		    }
		}
	    }
	}
    }
    sem_post (&sem);
    free (p);
    return NULL;
}

int main (int argc, char* argv[])
{
    FILE * file;
    char line[256];
    char* token, *value;
    int val, len, i, j;
    int ndx, start, stop, skip;
    int begin_at = 0;
    int end_at = INT_MAX;
    pthread_t pid;
    int found = 0;
    struct node* tmp;

    if (argc >= 2) {
	begin_at = atoi(argv[1]);
    }
    if (argc == 3) {
	end_at = atoi(argv[2]);
    }
		       
    memset (tseqs, 0, sizeof(tseqs));
    memset (dseqs, 0, sizeof(dseqs));

    file = fopen ("wordlists/master.txt", "r");
    while (!feof(file)) {
	if (fgets (line, sizeof(line), file)) {
	    token = strstr(line, ";");
	    if (!token) {
		fprintf (stderr, "No value found for line %s", line);
		return -1;
	    }
	    *token = '\0';
	    value = token+1;
	    token = strstr(value, " ");
	    if (token == NULL && atoi(value) != 50) {
		val = 50;
	    } else {
		val = atoi(value);
	    }
	    if (val < MIN_VALUE) continue;
	    
	    len = strlen(line);

	    /* Only allowed entries for a 3-4-3 formation */
	    if (len < 4) {
		start = 0;
		stop = 0;
		skip = 1;
	    } else if (len < 7) {
		start = 0;
		stop = len-3;
		skip = 1;
	    } else if (len == 7) { 
		start = 1;
		stop = 3;
		skip = 1;
	    } else if (len == 8) {
		start = 2;
		stop = 3;
		skip = 1;
	    } else if (len == 10) {
		start = 0;
		stop = 12;
		skip = 6;
	    } else if (len == 11) {
		start = 1;
		stop = 11;
		skip = 5;
	    } else if (len == 12) {
		start = 2;
		stop = 10;
		skip = 4;
	    } else if (len == 15) {
		start = 0;
		stop = 0;
		skip = 1;
		strcpy (spanners[scnt++], line);
	    } else if (len == 16) {
		start = 6;
		stop = 7;
		skip = 1;
	    } else {
		start = 0;
		stop = 0;
		skip = 1;
	    }
	    for (i = start; i < stop; i += skip) {
		ndx = 0;
		for (j = 0; j < 4; j++) {
		    ndx += (line[i+j]-'A')<<(5*j);
		    if (j == 2) tseqs[ndx] = 1;
		}
		found = 0;
		for (tmp = dseqs[ndx]; tmp; tmp = tmp->next) {
		    if (tmp->len == len && tmp->i == i) found = 1;
		}
		if (!found) {
		    tmp = malloc(sizeof(struct node));
		    tmp->len = len;
		    tmp->i = i;
		    tmp->next = dseqs[ndx];
		    dseqs[ndx] = tmp;
		}
	    }
	}
    }
    fclose (file);
    
    j = 0;
    for (i = 0; i < sizeof(tseqs); i++) {
	if (tseqs[i]) j++;
    }
    printf ("%d triple-fragmens\n", j);
 
    j = 0;
    for (i = 0; i < sizeof(dseqs)/sizeof(struct node *); i++) {
	if (dseqs[i]) j++;
    }
    printf ("%d quad-fragmens\n", j);

    if (scnt < end_at) end_at = scnt;

    sem_init (&sem, 0, CONCURRENCY);

    do {
	struct vars* v;
	sem_wait(&sem);
	v = (struct vars *) malloc (sizeof(struct vars));
	if (v == NULL) {
	    perror ("malloc");
	    exit (0);
	}
	v->begin_at = begin_at;
	v->end_at = end_at > begin_at + INCR ? begin_at + INCR : end_at;
	//printf ("Starting thread for %d-%d\n", v->begin_at, v->end_at);
	pthread_create (&pid, NULL, do_it, v);
	begin_at += 100;
    } while (begin_at < end_at);

    for (i = 0; i < CONCURRENCY; i++) {
	sem_wait(&sem); // Wait for threads to finish
    }

    return 0;
}
