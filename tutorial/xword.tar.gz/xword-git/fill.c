#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "board.h"
#include "types.h"

#define PARALLELISM 8

answer_t a_answers[MAX_ANSWERS/2];
answer_t d_answers[MAX_ANSWERS/2];
int a_answer_num = 0, d_answer_num = 0, blocks = 0;
int max_len;

typedef struct {
    int board_number;
    int len;
} sort_t;
sort_t sort_answers[MAX_ANSWERS];

int comp (const void* a, const void* b)
{
    const sort_t* pa = (const sort_t *) a;
    const sort_t* pb = (const sort_t *) b;
    return pb->len - pa->len;
}

void format ()
{
    fprintf (stderr, "format: fill [-b board file] [-w word list file] [-p partition file] [-m max # of matches]\n             [-v min. acceptable word value] [-y max. penalty] [-s]how solutions\n");
    exit (0);
}

int main (int argc, char* argv[])
{
    char* board = NULL;
    int board_index = 0;
    int height, width;    
    u_char* pgrid;
    char newboard[MAX_LEN][MAX_LEN];
    int i,j,k,rc;
    int board_number = 0;
    int child_number = 0;
    char partfile[256], freqfile[256];
    FILE* fp;
    pid_t pid;
    int status[MAX_ANSWERS];
    int slots[PARALLELISM], jobs[PARALLELISM];
    int no_more_jobs = 0, completed_jobs = 0;
    char dir[256] = "/tmp";
    int detailed = 0;

    for (i = 1; i < argc; i++) {
	if (!strncmp(argv[i],"-h",2)) {
	    format();
	} else if (!strncmp(argv[i], "-b",2)) {
	    if (argc > i+1) {
		board_index = i+1;
		board = argv[i+1];
		i++;
	    } else {
		format();
	    }
	} else if (!strncmp(argv[i], "-w",2)) {
	    if (argc > i+1) {
		i++;
	    } else {
		format();
	    }
	} else if (!strncmp(argv[i], "-p",2)) {
	    if (argc > i+1) {
		i++;
	    } else {
		format();
	    }
	} else if (!strncmp(argv[i], "-m",2)) {
	    if (argc > i+1) {
		i++;
	    } else {
		format();
	    }
	} else if (!strncmp(argv[i], "-v",2)) {
	    if (argc > i+1) {
		i++;
	    } else {
		format();
	    }
	} else if (!strncmp(argv[i], "-y",2)) {
	    if (argc > i+1) {
		i++;
	    } else {
		format();
	    }
	} else if (!strncmp(argv[i], "-f",2)) {
	    if (argc > i+1) {
		i++;
	    } else {
		format();
	    }
	} else if (!strncmp(argv[i], "-s",2)) {
		argv[i][0] = '\0';
	} else if (!strncmp(argv[i], "-x",2)) {
		detailed = 1;
		argv[i][0] = '\0';
	} else if (!strncmp(argv[i], "-a",2)) {
	} else if (!strncmp(argv[i], "-d",2)) {
	    if (argc > i+1) {
		argv[i][0] = '\0';
		i++;
		strcpy(dir, argv[i]);
		argv[i][0] = '\0';
	    } else {
		format();
	    }
	} else {
	    format();
	}
    }

    if (board == NULL) {
	format();
	return -1;
    }

    if (read_board_file (board, &height, &width, &pgrid)) return -1;
    if (extract_answers (pgrid, height, width, 0)) return -1;

    for (i = 0; i < a_answer_num; i++) {
	if (!a_answers[i].border_answer) {
	    // Make a copy of the board
	    for (j = 0; j < height; j++) {
		for (k = 0; k < width; k++) {
		    newboard[j][k] = pgrid[j*width+k];
		    if (newboard[j][k] == ' ') newboard[j][k] = '@';
		    if (newboard[j][k] == 0) newboard[j][k] = '_';
		}
	    }
	    // Change this answer to be a border answer
	    for (j = 0; j < a_answers[i].len; j++) {
		if (newboard[a_answers[i].start_row][a_answers[i].start_col+j] == '_') {
		    newboard[a_answers[i].start_row][a_answers[i].start_col+j] = 'b';
		}
	    }
	    // Print out the board
	    sprintf (partfile, "%s/%s.%d", dir, board, board_number);
	    fp = fopen (partfile, "w");
	    if (fp == NULL) {
		fprintf (stderr, "Cannot open partition file %s\n", partfile);
		return -1;
	    }
	    fprintf (fp, "%d %d\n", height, width);
	    for (j = 0; j < height; j++) {
		for (k = 0; k < width; k++) {
		    fprintf (fp, "%c", newboard[j][k]);
		}
		fprintf (fp, "\n");
	    }
	    fclose (fp);
	    sort_answers[board_number].board_number = board_number;
	    sort_answers[board_number].len = a_answers[i].len;
	    board_number++;
	}
    }
    for (i = 0; i < d_answer_num; i++) {
	if (!d_answers[i].border_answer) {
	    // Make a copy of the board
	    for (j = 0; j < height; j++) {
		for (k = 0; k < width; k++) {
		    newboard[j][k] = pgrid[j*width+k];
		    if (newboard[j][k] == ' ') newboard[j][k] = '@';
		    if (newboard[j][k] == 0) newboard[j][k] = '_';
		}
	    }
	    // Change this answer to be a border answer
	    for (j = 0; j < d_answers[i].len; j++) {
		if (newboard[d_answers[i].start_row+j][d_answers[i].start_col] == '_') {
		    newboard[d_answers[i].start_row+j][d_answers[i].start_col] = 'b';
		}
	    }
	    // Print out the board
	    sprintf (partfile, "%s/%s.%d", dir, board, board_number);
	    fp = fopen (partfile, "w");
	    if (fp == NULL) {
		fprintf (stderr, "Cannot open partition file %s\n", partfile);
		return -1;
	    }
	    fprintf (fp, "%d %d\n", height, width);
	    for (j = 0; j < height; j++) {
		for (k = 0; k < width; k++) {
		    fprintf (fp, "%c", newboard[j][k]);
		}
		fprintf (fp, "\n");
	    }
	    fclose (fp);
	    sort_answers[board_number].board_number = board_number;
	    sort_answers[board_number].len = d_answers[i].len;
	    board_number++;
	}
    }

    // Sort the answers by length
    qsort (sort_answers, board_number, sizeof(sort_t), comp);
	
    // Now launch off child placement jobs in parallel
    memset (status, 0, sizeof(status));
    memset (slots, 0, sizeof(slots));

    do {
	for (i = 0; i < PARALLELISM; i++) {
	    if (slots[i] == 0) break;
	}
	if (i < PARALLELISM && !no_more_jobs) {
	    printf ("Free slot at %d\n", i);
	    /* Free slot - start a job */
	    for (child_number = 0; child_number < board_number; child_number++) {
	      if (status[child_number] == 0 || status[child_number] == 2) break;
	    }
	    if (child_number == board_number) {
		printf ("All jobs have been started\n");
		no_more_jobs = 1;
		continue;
	    }
	    printf ("child_number is %d\n", child_number);

	    pid = fork ();
	    if (pid == 0) {
		sprintf (partfile, "%s/fill.%d", dir, sort_answers[child_number].board_number);
		if (status[child_number] == 0) {
		    printf ("Starting placer for board %d\n", sort_answers[child_number].board_number);
		    fflush(stdout); 
		    rc = open (partfile, O_CREAT|O_WRONLY|O_TRUNC, 0644);
		    if (rc < 0) {
			perror ("Cannot open output file");
			return -1;
		    } 
		    dup2 (rc,1);
		    sprintf (partfile, "%s/%s.%d", dir, board, sort_answers[child_number].board_number);
		    child_number++;
		    argv[board_index] = partfile;
		    if (detailed) {
			    execv ("./detail-placer", argv);
		    } else {
			    execv ("./placer", argv);
		    }			    
		} else { /* status == 1 */
		    printf ("Starting parfreqs for board %d\n", sort_answers[child_number].board_number);
		    fflush(stdout); 
		    sprintf (freqfile, "%s/freqs.%d", dir, sort_answers[child_number].board_number);
		    rc = open (freqfile, O_CREAT|O_WRONLY|O_TRUNC, 0644);
		    if (rc < 0) {
			perror ("Cannot open output file");
			return -1;
		    } 
		    dup2 (rc,1);
		    execl ("./parfreqs.py", "parfreqs.py", partfile, NULL);
		}
	    } else {
		slots[i] = pid;
		jobs[i] = child_number;
		status[child_number]++;
	    }
	} else {
	    // Need to wait for a job to finish
	    printf ("waiting for a finisher\n");
	    int wstatus;
	    pid = wait(&wstatus);
	    printf ("pid %d finished with status %x\n", pid, wstatus);
	    if (pid < 0) break;
	    for (i = 0; i < PARALLELISM; i++) {
		if (slots[i] == pid) {
		    slots[i] = 0;
		    status[jobs[i]]++;
		    if (status[jobs[i]] == 4) {
			completed_jobs++;
			printf ("completed jobs: %d\n" , completed_jobs);
		    } else {
			no_more_jobs = 0; // More jobs have become startable
		    }
		}
	    }
	}
    } while (completed_jobs < board_number);

    return 0;
}
