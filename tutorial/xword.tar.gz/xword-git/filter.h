#ifndef __FILTER_H__
#define __FILTER_H__

int read_freqs (char* filename);

#endif
