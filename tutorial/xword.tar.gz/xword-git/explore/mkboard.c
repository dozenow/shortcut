#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>

#define CONCURRENCY 8

char* wordlist = "";
sem_t sem;
int goto16 = 0;

int test_board (char* puzzle, char* wordlist, int val, int y)
{
    int rc;
    char cmd[256];
    
    if (y > 0) {
	sprintf (cmd, "timelimit -t 600 -s 9 ../placer -b board.%s -w %s -v %d -m 1 -s -y %d > solution.%s", 
		 puzzle, wordlist, val, y, puzzle);
    } else {
	sprintf (cmd, "timelimit -t 600 -s 9 ../placer -b board.%s -w %s -v %d -m 1 -s > solution.%s", 
		 puzzle, wordlist, val, puzzle);
    }
    printf ("%s\n", cmd);
    rc = system (cmd);
    if (WEXITSTATUS(rc) == 137) {
	printf ("Timeout on board.%s value %d max_pen %d\n", puzzle, val, y);
    }
    sprintf (cmd, "grep SOLUTION solution.%s > /dev/null", puzzle);
    rc = system (cmd);
    return (rc == 0);
}

void* find_best_fit (void * arg)
{
    char cmd[256];
    char* puzzle = (char *) arg;
    int max, min, val;

    if (test_board(puzzle, wordlist, 30, 0) == 0) goto done;
    printf ("Value 30 solution\n");
    sprintf (cmd, "cp solution.%s solution.%s.30\n", puzzle, puzzle);
    system (cmd);
    if (test_board(puzzle, wordlist, 40, 0) == 0) {
	// Do a binary search on 30
	min = 0;
	max = 40;
	if (test_board(puzzle, wordlist, 30, max) == 0) goto done;
	sprintf (cmd, "cp solution.%s solution.%s.30.40\n", puzzle, puzzle);
	system (cmd);
	while (max > min+1) {
	    val = (max+min)/2;
	    if (test_board(puzzle, wordlist, 30, val) == 0) {
		printf ("Value 30 - %d solution failed\n", val);
		min = val;
	    } else {
		printf ("Value 30 - %d solution\n", val);
		max = val;
		sprintf (cmd, "cp solution.%s solution.%s.30.%d\n", puzzle, puzzle, val);
		system (cmd);
	    }
	}
	goto done;
    }
    printf ("Value 40 solution\n");
    sprintf (cmd, "cp solution.%s solution.%s.40\n", puzzle, puzzle);
    system (cmd);
    if (test_board(puzzle, wordlist, 41, 0) == 0) {
	// Do a binary search on 40
	min = 0;
	max = 20;
	if (test_board(puzzle, wordlist, 40, max) == 0) goto done;
	sprintf (cmd, "cp solution.%s solution.%s.40.20\n", puzzle, puzzle);
	system (cmd);
	while (max > min+1) {
	    val = (max+min)/2;
	    if (test_board(puzzle, wordlist, 40, val) == 0) {
		printf ("Value 40 - %d solution failed\n", val);
		min = val;
	    } else {
		printf ("Value 40 - %d solution\n", val);
		max = val;
		sprintf (cmd, "cp solution.%s solution.%s.40.%d\n", puzzle, puzzle, val);
		system (cmd);
	    }
	}
	goto done;
    }
    printf ("Value 41 solution\n");
    sprintf (cmd, "cp solution.%s solution.%s.41\n", puzzle, puzzle);
    system (cmd);
    if (test_board(puzzle, wordlist, 50, 0) == 0) goto done;
    printf ("Value 50 solution\n");
    sprintf (cmd, "cp solution.%s solution.%s.50\n", puzzle, puzzle);
    system (cmd);

  done:
    sem_post (&sem);
    sprintf (cmd, "rm solution.%s\n", puzzle);
    system (cmd);
    return NULL;
}

int addcount;
char adders[100][30];

int parse_add_file (char* filename)
{
    FILE* file;
    char buf[80];
    char* p;
    int len, minlen = 100;

    addcount = 0;
    memset (adders, 0, sizeof(adders));

    file = fopen (filename, "r");
    if (!file) {
	fprintf (stderr, "Cannot open file %s\n", filename);
	exit (1);
    }

    while (!feof(file)) {
	fgets (buf, sizeof(buf), file);
	p = strchr(buf, ';');
	if (p) {
	    *p = '\0';
	    printf ("%s (%d)\n", buf, (int) strlen(buf));
	    len = strlen(buf);
	    strcpy (adders[addcount++], buf);
	    if (len < minlen) minlen = len;
	}
    }

    fclose(file);
    return minlen;
}

int height, width;
char grid[16][16];

struct themer {
    int x, y, length;
};
struct themer themers[100];
int placed[100];

int read_board (char* filename)
{
    FILE* file;
    char line[80];
    int i, j;

    file = fopen (filename, "r");
    if (fgets (line, sizeof(line), file)) {
	sscanf (line, "%d %d", &height, &width);
	for (i = 0; i < height; i++) {
	    if (fgets (line, sizeof(line), file)) {
		for (j = 0; j < width; j++) {
		    grid[i][j] = line[j];
		}
	    } else {
		fclose(file);
		return -1;
	    }
	}
    } else {
	fclose(file);
	return -1;
    }

    fclose(file);
    return 0;
}

int find_theme_slots (int min_length)
{
    int i, j, start_j, tcnt = 0;
    
    for (i = 0; i < height; i++) {
	start_j = 0;
	for (j = 0; j < width; j++) {
	    if (grid[i][j] == '@') {
		if (j-start_j >= min_length) {
		    themers[tcnt].x = start_j;
		    themers[tcnt].y = i;
		    themers[tcnt].length = j-start_j;
		    tcnt++;
		}
		start_j = j+1;
	    }
	}
	if (j-start_j >= min_length) {
	    themers[tcnt].x = start_j;
	    themers[tcnt].y = i;
	    themers[tcnt].length = j-start_j;
	    tcnt++;

	}
    }
    return tcnt;
}

int write_board (char* filename)
{
    FILE* file;
    int i, j;

    file = fopen (filename, "w");
    if (file == NULL) return -1;

    fprintf (file, "%d %d\n", height, width);
    for (i = 0; i < height; i++) {
	for (j = 0; j < width; j++) {
	    fprintf (file, "%c", grid[i][j]);
	}
	fprintf (file, "\n");
    }
    fclose (file);
    return 0;
}

int pcnt; 
int place_themers (int tcnt, char* filename, int revealer)
{
    char newfile[256];
    int i, j;
    int bcnt = 0;

    if (tcnt == 0) {
	sprintf (newfile, "%s.%d", filename, pcnt++);
	write_board (newfile);
	return 1;
    } else {
	if (revealer) {
	    if (themers[tcnt-1].length == strlen(adders[addcount-1])) {
		placed[addcount-1] = 1;
		for (j = 0; j < themers[tcnt-1].length; j++) {
		    grid[themers[tcnt-1].y][themers[tcnt-1].x+j] = adders[addcount-1][j];
		}
		bcnt += place_themers(tcnt-1, filename, 0);
	    } else {
		return 0;
	    }
	}
	for (i = 0; i < addcount; i++) {
	    if (!placed[i] && strlen(adders[i]) == themers[tcnt-1].length) {
		placed[i] = 1;
		for (j = 0; j < themers[tcnt-1].length; j++) {
		    grid[themers[tcnt-1].y][themers[tcnt-1].x+j] = adders[i][j];
		}
		bcnt += place_themers (tcnt-1, filename, 0);
		placed[i] = 0;
	    }
	}
    }
    return bcnt;
}

int main (int argc, char* argv[])
{
    FILE* inf;
    char cmd[256], bname[256], bname2[256];
    char buf[80];
    char* p;
    pthread_t tid;
    wordlist = argv[1];
    char* addfile = NULL;
    int i, minlen, tcnt, bcnt;
    int revealer = 0;

    if (argc < 2) {
	fprintf (stderr, "format: mkboard wordlist.txt [-16] [-add addfile] [-revealer]\n");
	exit (0);
    }

    for (i = 2; i < argc; i++) {
	if (!strcmp(argv[i], "-16")) {
	    goto16 = 1;
	} else if (!strcmp(argv[i], "-add")) {
	    addfile = argv[i+1];
	    i++;
	} else if (!strcmp(argv[i], "-revealer")) {
	    revealer = 1;
	}
    }

    sem_init (&sem, 0, CONCURRENCY);

    if (addfile) {
	minlen = parse_add_file (addfile);
	printf ("Minimum length is %d\n", minlen);
    }

    inf = fopen ("/tmp/grids", "r");
    if (inf == NULL) perror ("fopen gridlist");

    while (!feof(inf)) {
	fgets (buf, sizeof(buf), inf);
	p = buf;
	while (*p != ' ') p++;
	*p = '\0';

	printf ("Puzzle grid %s\n", buf);
	if (goto16) {
	    sprintf (cmd, "../puzzles/gridconv ../puzzles/%s -16 > puzzle.conv", buf);
	} else {
	    sprintf (cmd, "../puzzles/gridconv ../puzzles/%s > puzzle.conv", buf);
	}
	system (cmd);

	if (addfile) {
	    read_board("puzzle.conv");
	    tcnt = find_theme_slots (minlen);
	    memset (placed, 0, sizeof(placed));
	    pcnt = 1;
	    sprintf (bname, "board.%s", buf);
	    bcnt = place_themers (tcnt, bname, revealer);
	    for (i = 0; i < bcnt; i++) {
		sprintf (bname2, "%s.%d", bname, i+1);
		system (cmd);
		sem_wait (&sem);
		pthread_create (&tid, NULL, find_best_fit, strdup(bname2+6));
	    }
	} else {
	    sprintf (cmd, "cp puzzle.conv board.%s\n", buf);
	    system (cmd);
	    sem_wait (&sem);
	    pthread_create (&tid, NULL, find_best_fit, strdup(buf));
	}
    }

    for (i = 0; i < CONCURRENCY; i++) {
	sem_wait (&sem);
    }

    fclose (inf);
    return 0;
}
