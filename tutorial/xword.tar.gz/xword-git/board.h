#ifndef __BOARD_H__
#define __BOARD_H__

int extract_answers (u_char* board, int height, int width, int replace_border_squares);
int read_board_file (char* filename, int* pheight, int* pwidth, u_char** ppgrid);

#endif
