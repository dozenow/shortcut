#!/usr/bin/python
import sys;
import re;

dict = {};
fh = open ("/home/jflinn/xword/puzzles/wordfreq", "r");
for line in fh:
    (word, freq) = line.split()
    dict[word] = int(freq);
fh.close()

values = {}
annotations = {}
fh = open ("wordlists/master.txt", "r");
for line in fh:
    (word, value) = line.split(";")
    v = value.split();
    values[word] = int(v[0]);
    if (len(v) == 2):
        annotations[word] = v[1];
fh.close()

entries = {}
fh = open (sys.argv[1],"r");
for line in fh:
    i = 0;
    m = re.match("across \d+ (\w+)\s", line)
    if m:
        i = i + 1
        if not (m.group(1) in entries):
            entries[m.group(1)] = 1
    m = re.match("down \d+ (\w+)\s", line)
    if m:
        i = i + 1
        if not (m.group(1) in entries):
            entries[m.group(1)] = 1

for word in sorted(entries.keys()):
    if (word in values):
        value = values[word]
    else:
        value = 100
    if (word in dict):
        print "%s:%s (%d)"%(word, value, dict[word]),
    else:
        print "%s:%s (0)"%(word, value),
    if (word in annotations):
        print "***", annotations[word],
    print
        
fh.close()
            
