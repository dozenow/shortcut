#!/bin/sh

# Make lists with 4+ and 5+ words represented by first 4/5 letters
./mktquadtop.py > wordlists/ttop.txt
./mktquadbottom.py > wordlists/tbottom.txt
./mktquadtop5.py > wordlists/ttop5.txt
./mktquadbottom5.py > wordlists/tbottom5.txt

# Generate all matches - set value to 25 in repeater1.pl
rm ttop.out.*
./placer -b grid.top -w wordlists/ttop.txt -v 25 -s -l 14 > ttop.out.a

# run again w/bottom list and out
rm tbottom.out.*
./placer -b grid.top -w wordlists/tbottom.txt -v 25 -s -l 14 > tbottom.out.a

# Collect the results
./mkttoppart.py > ttop.part
./mktbottompart.py > tbottom.part

# Generate grids
./tquadall.py