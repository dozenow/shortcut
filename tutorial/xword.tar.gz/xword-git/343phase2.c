#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>

#define MAX_BLOCKS 34

#define CONCURRENCY 8
#define INCR 10000

struct tcmd {
    int start_at;
    int end_at;
};

sem_t sem;
int done = 0;

void* do_it (void* p)
{
    struct tcmd* pcmd = (struct tcmd *) p;
    FILE *file, *fileo;
    char line[256], filename[256], ofilename[256], cmd[256];
    int puzzle = 0, start = 0, rc, blocks;

    printf ("doing boards %d to %d \n", pcmd->start_at, pcmd->end_at);
    fflush (stdout);

    file = fopen("343quad.out", "r"); 
    if (!file) {
        perror ("fopen");
	exit (0);
    }

    sprintf (filename, "/tmp/board.%d", pcmd->start_at);

    while (!feof(file)) {
	if (fgets (line, sizeof(line), file)) {
	    if (!strncmp (line, "16 15", 5)) {
		puzzle = puzzle + 1;
		if (puzzle > pcmd->end_at) break;
		if (puzzle >= pcmd->start_at) {
		    start = 1;
		    fileo = fopen (filename, "w");
		    if (!fileo) {
			perror ("fopen board");
			exit (0);
		    }
		}
	    }

	    if (start > 0) {
		fprintf (fileo, "%s", line);
		start++;
	    }
	    if (start == 19) {
		fclose (fileo);
		if (!strncmp(line, "blocks: ", 8)) {
		    blocks = atoi(line+8);
		    if (blocks <= MAX_BLOCKS) {
			sprintf (cmd, "./placer -b %s -w wordlists/master.txt -v 25 -m 1 -s > /tmp/results.%d", filename, pcmd->start_at);
			rc = system(cmd);
			sprintf (cmd, "grep \"\\-SOLUTION\\-\" /tmp/results.%d > /dev/null", pcmd->start_at);
			rc = system(cmd);
			if (rc != 256) {
			    sprintf (ofilename, "343p2results/qboard.%d", puzzle);
			    rc = rename (filename, ofilename);
			    if (rc < 0) {
				perror ("rename 1");
				exit (0);
			    }
			}
		    }
		} else {
		    printf ("Invalid line: %s\n", line);
		}
		start = 0;
	    }
	}
    }
    if (feof(file)) done = 1;

    fclose (file);
    free (pcmd);
    sem_post (&sem);
    return NULL;
}

int main (int argc, char* argv[])
{
    struct tcmd* pcmd;
    pthread_t pid;
    int i, begin_at = 0;

    sem_init (&sem, 0, CONCURRENCY);

    if (argc > 1) {
	begin_at = atoi(argv[1]);
    }

    do {
	sem_wait(&sem);
	
	pcmd = malloc(sizeof(struct tcmd));
	pcmd->start_at = begin_at;
	pcmd->end_at = begin_at + INCR - 1;
	pthread_create (&pid, NULL, do_it, pcmd);
	begin_at += INCR;
    } while (!done);

    for (i = 0; i < CONCURRENCY; i++) {
	sem_wait(&sem); // Wait for threads to finish
    }
    return 0;
}
        
