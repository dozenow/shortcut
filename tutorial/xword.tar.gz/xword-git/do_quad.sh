#!/bin/sh

# Make lists with 4+ and 5+ words represented by first 4/5 letters
./mkquadtop.py > wordlists/top.txt
./mkquadbottom.py > wordlists/bottom.txt
./mkquadtop5.py > wordlists/top5.txt
./mkquadbottom5.py > wordlists/bottom5.txt

# Now make grids for top and bottom placements - split by letter for now
./makegrids.py

# Generate all matches - set value to 25 in repeater1.pl
#ulimit -v 15000000
#rm top.out.*
#./repeater1.pl -b grid.top -o top.out -w wordlists/top.txt -v 25

# run again w/bottom list and out
#rm bottom.out.*
#./repeater1.pl -b grid.top -o bottom.out -w wordlists/bottom.txt -v 25

# Collect the results
#./mktoppart.py > top.part
#./mkbottompart.py > bottom.part

# Generate grids
#./quadall.py
