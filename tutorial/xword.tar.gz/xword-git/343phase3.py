#!/usr/bin/python

import sys;
import os

MAX = 34

done = {}
fh = open ("phase3-done.txt", "r")
for line in fh:
    done[line.strip()] = 1
fh.close()

by_blocks = {}
os.system("grep blocks 343p2results/* > qboards.txt")
fh = open ("qboards.txt")
for line in fh:
    (board, token, cnt) = line.split(":")
    if board in done:
        continue
    blocks = int(cnt)
    if blocks > MAX:
        continue
    if blocks in by_blocks:
        by_blocks[blocks].append(board)
    else:
        by_blocks[blocks] = []

fh.close()

fh = open ("phase3-list.txt", "w")
for blocks in sorted(by_blocks.keys()):
    print blocks, "blocks:"
    for board in by_blocks[blocks]:
        fh.write(board + "\n")
fh.close()
os.system("time ./343phase3s phase3-list.txt " + str(MAX) + " 1800 4")



