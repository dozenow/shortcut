#!/usr/bin/python
import sys;
import re;
import os;

    
words = {};
fh = open ("wordlists/master.txt", "r");
for line in fh:
    tokens = line.split()
    (word,value) = tokens[0].split(";")
    if word in words:
        print line, "is duplicate"
    value = int(value)
    if len(tokens) == 2:
        note = tokens[1]
    else:
        note = ""
    if (value >= 50 and note != "" and note != "+"):
        print word, value, note
    if (value < 50 and note == "+"):
        print word, value, note
    words[word] = (value,note)
fh.close()

crowd = {};
fh = open ("wordlists/crowd.txt", "r");
for line in fh:
    tokens = line.split()
    (word,value) = tokens[0].split(";")
    if word in crowd:
        print line, "is duplicate"
    value = int(value)
    crowd[word] = value
fh.close()

def doword (word,count):
    done = False;
    while not done:
        print "%s %s"%(word,count),
        if word in crowd:
            print ("[%d]"%crowd[word])
        else:
            print
        s = raw_input ("> ");
        s.strip();
        if (s == "q" or s == "Q"):
            done = True;
            return 1;
        elif (s == "s" or s == "S"):
            os.system ("grep \"^" + word + " \" puzzles/puzzle.db");
            continue;
        elif (s == "d" or s == "D"):
            del words[word];
            done = True;
        elif (s[:2] == "V "):
            tokens = s.split()
            if (len(tokens) == 2):
                fword = tokens[1].strip()
                if (fword in words):
                    (value,note) = words[fword]
                    print fword, "has value", value, note
                else:
                    print fword, "not found"
            else:
                print "syntax error"
            continue;
        elif (s == "50"):
            words[word] = (50,"+");
            done = True;
        else:
            tok = s.split(" ");
            if (len(tok) != 2):
                print "syntax error: bad number of tokens"
                continue;
            else:
                try:
                    val = int(tok[0]);
                except ValueError:
                    val = 0
                if (val == 0 or val >= 50):
                    print "syntax error: bad number"
                    continue;
                else:
                    words[word] = (val,tok[1])
                    done = True;
        return 0;

exit = False;            
fh = open("newfreqs")
for line in fh:
    tokens = line.split()
    if (len(tokens) == 2):
        count = tokens[1]
        (word,value) = tokens[0].split(":")
        value = int(value);
        if (value <= 50):
            if (word in words):
                (value,note) = words[word]
                if (not note):
                    if (doword (word,count)):
                        break;
            else:
                print word, "is no longer in master list"
fh.close()

outfh = open("/tmp/master.txt","w")
sys.stdout = outfh
for k in sorted(words.keys()):
    (value,note) = words[k]
    if note:
        print ("%s;%d %s"%(k,value,note));
    else:
        print ("%s;%d"%(k,value));
        
outfh.close()

