#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <semaphore.h>
#include <pthread.h>
#include <assert.h>

void
visit (int x, int y, char grid[16][15], char visited[16][15])
{
    if (x < 0 || x >= 15 || y < 0 || y >= 16) return;
    if (visited[y][x]) return;
    visited[y][x] = 1;
    visit(x-1,y,grid,visited);
    visit(x,y-1,grid,visited);
    visit(x,y+1,grid,visited);
    visit(x+1,y,grid,visited);
}

int 
is_partitioned (char grid[16][15])
{
    int i, j;
    char visited[16][15];
    
    memset (visited, 0, sizeof(visited));
    for (i = 0; i < 16; i++) {
	for (j = 0; j < 15; j++) {
	    if (grid[i][j] == '@') {
		visited[i][j] = 1;
	    }
	}
    }
    visit (0,0,grid,visited);
    for (i = 0; i < 16; i++) {
	for (j = 0; j < 15; j++) {
	    if (!visited[i][j]) {
		return 1;
	    }
	}
    }
    return 0;
}

int make_partition (int x, int y, char grid[16][15])
{
    int cnt, i;

    if (grid[y][x] != 'x') return 0;

    grid[y][x] = '_';
    cnt = 1;

    for (i = x+1; i < 15 && grid[y][i] != '@'; i++) cnt += make_partition(i, y, grid);
    for (i = x-1; i >= 0 && grid[y][i] != '@'; i--) cnt += make_partition(i, y, grid);
    for (i = y+1; i < 16 && grid[i][x] != '@'; i++) cnt += make_partition(x, i, grid);
    for (i = y-1; i >= 0 && grid[i][x] != '@'; i--) cnt += make_partition(x, i, grid);
    return cnt;
}

int 
isblock (int y, int x, char grid[16][15])
{
    return (grid[y][x] == '@');
}

int
block (int y, int x, char grid[16][15])
{
    if (y == -1 || y == 16) return 0; // OK to put a block "on the edge"
    if (x == -1 || x == 15) return 0;

    if (isblock(y,x,grid)) return 0;

    //printf ("block at <%d,%d>\n", y, x);

    if (grid[y][x] != '_') {
	grid[y][x] = '@';
    } else {
	return -1;
    }

    // Check left
    if (x == 1) {
	if (block (y, 0, grid) < 0) return -1;
    } else if (x == 2) {
	if (block (y, 1, grid) < 0) return -1;
	if (block (y, 0, grid) < 0) return -1;
    } else if (x != 0) {
	if (isblock(y,x-2,grid)) {
	    if (block (y, x-1, grid) < 0) return -1;
	}
	if (isblock(y,x-3,grid)) {
	    if (block (y, x-1, grid) < 0) return -1;
	    if (block (y, x-2, grid) < 0) return -1;
	}
    }

    // Check right
    if (x == 13) {
	if (block (y, 14, grid) < 0) return -1;
    } else if (x == 12) {
	if (block (y, 13, grid) < 0) return -1;
	if (block (y, 14, grid) < 0) return -1;
    } else if (x != 14) {
	if (isblock(y,x+2,grid)) {
	    if (block (y, x+1, grid) < 0) return -1;
	}
	if (isblock(y,x+3,grid)) {
	    if (block (y, x+1, grid) < 0) return -1;
	    if (block (y, x+2, grid) < 0) return -1;
	}
    }

    // Check top
    if (y == 1) {
	if (block (0, x, grid) < 0) return -1;
    } else if (y == 2) {
	if (block (1, x, grid) < 0) return -1;
	if (block (0, x, grid) < 0) return -1;
    } else if (y != 0) {
	if (isblock(y-2,x, grid)) {
	    if (block (y-1, x, grid) < 0) return -1;
	}
	if (isblock(y-3,x,grid)) {
	    if (block (y-1, x, grid) < 0) return -1;
	    if (block (y-2, x, grid) < 0) return -1;
	}
    }
	
    // Check bottom
    if (y == 14) {
	if (block (15, x, grid) < 0) return -1;
    } else if (y == 13) {
	if (block (14, x, grid) < 0) return -1;
	if (block (15, x, grid) < 0) return -1;
    } else if (y != 15) {
	if (isblock(y+2,x,grid)) {
	    if (block (y+1, x, grid) < 0) return -1;
	}
	if (isblock(y+3,x,grid)) {
	    if (block (y+1, x, grid) < 0) return -1;
	    if (block (y+2, x, grid) < 0) return -1;
	}
    }

    // Symmetry
    return block (15-y, 14-x, grid);
}

int 
isopensquare (int y, int x, char grid[16][15])
{
    return (grid[y][x] == '_');
}


int
opensquare (int y, int x, char grid[16][15])
{
    assert (x >= 0 && y >= 0 && x < 15 && y < 16);
    if (isopensquare(y,x,grid)) return 0;

    if (grid[y][x] != '@') {
	grid[y][x] = '_';
    } else {
	return -1;
    }
    
    // Symmetry
    return opensquare (15-y, 14-x, grid);
}

struct unk {
    char x;
    char y;
};
    
int main (int argc, char* argv[])
{
    FILE * file;
    char line[256], filename[256];
    char grid[16][15], wgrid[16][15];
    int i, j, b, u, done, ocnt = 1;
    long rc;
    int num_unknowns = 0;
    int part, open_squares, good;
    struct unk unknowns[30];
    int max_value = 38;

    if (argc < 2) {
	fprintf (stdout, "343phase3 <qboard> [max]\n");
	exit (0);
    }
    if (argc == 3) {
	max_value = atoi(argv[2]);
    }

    // read board
    file = fopen (argv[1], "r");
    if (file == NULL) {
	perror("fopen");
	return -1;
    }
    i = 0;
    while (!feof(file)) {
	if (fgets (line, sizeof(line), file)) {
	    if (i > 0) {
		for (j = 0; j < 15; j++) {
		    grid[i-1][j] = line[j];
		}
	    }
	    i = i+1;
	}
    }
    fclose (file);

    // determine number of unknowns
    for (i = 3; i < 5; i++) {
	for (j = 0; j < 15; j++) {
	    if (grid[i][j] == 'x') {
		unknowns[num_unknowns].x = j;
		unknowns[num_unknowns].y = i;
		num_unknowns++;
	    }
	}
    }
    printf ("%d unknowns\n", num_unknowns);

    // Now generate all possible boards with those unknowns
    for (i = 0; i < 3; i++) {
	for (j = 0; j < 15; j++) {
	    grid[i][j] = '_';
	}
    }
    for (i = 13; i < 16; i++) {
	for (j = 0; j < 15; j++) {
	    grid[i][j] = '_';
	}
    }
    for (b = 0; b < (1 << num_unknowns); b++) {
	memcpy (wgrid, grid, sizeof(grid));
	done = 0;
	// First put in blanks
	for (u = 0; u < num_unknowns && !done; u++) {
	    if ((b >> u)%2 == 0) {
		if (opensquare (unknowns[u].y, unknowns[u].x, wgrid) == -1) done = 1;
	    }
	}
	// Then put in blocks 
	for (u = 0; u < num_unknowns && !done; u++) {
	    if ((b >> u)%2 == 1) {
		if (block (unknowns[u].y, unknowns[u].x, wgrid) == -1) done = 1;
	    }
	}
	if (!done) {
	    if (is_partitioned(wgrid)) {
		done = 1;
	    }
	}
	if (!done) {
	    // Try this board
	    open_squares = 0;

	    for (i = 0; i < 16; i++) {
		for (j = 0; j < 15; j++) {
		    if (wgrid[i][j] == '_') {
			wgrid[i][j] = 'x';
			open_squares++;
		    }
		}
	    }
	    part = make_partition (0, 0, wgrid);
	    if (240-60-open_squares <= max_value) {

		file = fopen("/tmp/board.343phase3", "w");
		if (file == NULL) {
		    perror ("fopen board\n");
		    return -1;
		}
		fprintf (file, "16 15\n");
		for (i = 0; i < 16; i++) {
		    for (j = 0; j < 15; j++) {
			fprintf (file, "%c", wgrid[i][j]);
		    }
		    fprintf (file, "\n");
		}
		fclose (file);
		
		good = 0;
		rc = system ("timelimit -s 9 -t 1800 ./placer -b /tmp/board.343phase3 -w wordlists/master.txt -v 25 -m 1 -s > /tmp/solution.343phase3");
		if (WEXITSTATUS(rc) == 137) {
		    printf ("timeout exceeded\n");
		    file = fopen ("phase3-timeout-30.txt", "a");
		    if (file == NULL) {
			fprintf (stderr, "cannot open timeout file\n");
			exit (0);
		    }
		    fprintf (file, "%s %d\n", argv[1], b);
		    fclose (file);
		    continue;
		}
		rc = system("grep \"\\-SOLUTION\\-\" /tmp/solution.343phase3");
		if (rc != 256) {
		    printf ("top! (%d out of %d open squares in partition\n", part, open_squares);
		    if (part != open_squares) {
			for (i = 0; i < 16; i++) {
			    for (j = 0; j < 15; j++) {	
				if (wgrid[i][j] == '_') {
				    wgrid[i][j] = 'x';
				}
			    }
			}
			part = make_partition (0, 15, wgrid);
			
			file = fopen("/tmp/board.343phase3", "w");
			if (file == NULL) {
			  perror ("fopen board\n");
			  return -1;
			}
			fprintf (file, "16 15\n");
			for (i = 0; i < 16; i++) {
			  for (j = 0; j < 15; j++) {
			    fprintf (file, "%c", wgrid[i][j]);
			  }
			  fprintf (file, "\n");
			}
			fclose (file);

			rc = system ("timelimit -s 9 -t 1800 ./placer -b /tmp/board.343phase3 -w wordlists/master.txt -v 25 -m 1 -s > /tmp/solution.343phase3");
			if (WEXITSTATUS(rc) == 137) {
			    printf ("timeout exceeded\n");
			    file = fopen ("phase3-timeout-30.txt", "a");
			    if (file == NULL) {
				fprintf (stderr, "cannot open timeout file\n");
				exit (0);
			    }
			    fprintf (file, "%s %d\n", argv[1], b);
			    fclose (file);
			} else {
			    rc = system("grep \"\\-SOLUTION\\-\" /tmp/solution.343phase3");
			    if (rc != 256) {
				printf ("bottom!\n");
				good = 1;
			    }
			}
		    } else {
			good = 1;
		    }
		    if (good) {
			for (i = 0; i < 16; i++) {
			    for (j = 0; j < 15; j++) {	
				if (wgrid[i][j] == 'x') wgrid[i][j] = '_';
			    }
			}
			sprintf (filename, "%s.%d", argv[1], ocnt++);
			filename[4] = '3'; // hack
			file = fopen(filename, "w");
			if (file == NULL) {
			    perror ("fopen outboard\n");
			    return -1;
			}
			fprintf (file, "16 15\n");
			for (i = 0; i < 16; i++) {
			    for (j = 0; j < 15; j++) {
				fprintf (file, "%c", wgrid[i][j]);
			    }
			    fprintf (file, "\n");
			}
			fprintf (file, "blocks: %d\n", 240-60-open_squares);
			fclose (file);
		    }
		}
	    } else {
		printf ("blocks: %d\n", 240-60-open_squares);
	    }
	}
    }
    return 0;
}
