#include <stdio.h>
#include <stdlib.h>
#include "board.h"
#include "types.h"

extern answer_t a_answers[MAX_ANSWERS/2];
extern answer_t d_answers[MAX_ANSWERS/2];
extern int a_answer_num, d_answer_num, max_len, blocks;

//#define DEBUG

#ifdef DEBUG
#define DPRINT printf
#else 
#define DPRINT(x,...)
#endif

#define EMPTY ' '

int 
extract_answers (u_char* board, int height, int width, int replace_border_squares)
{
    int i, j, k, start_at;
    cross_t aboard[height*width];
    cross_t dboard[height*width];
    int border_squares, oob_squares, prefilled_squares;

    max_len = 0;

    for (i = 0; i < height; i++) {
	start_at = 0;
	while (start_at < width) {

	    // Skip blanks at beginning of line
	    while (start_at < width && board[i*width+start_at] == EMPTY) start_at++;
	    if (start_at == width) break;

	    border_squares = oob_squares = prefilled_squares = 0;
	    for (j = start_at; j < width; j++) {
		if (board[i*width+j] == EMPTY) break;
		aboard[width*i+j].answer = a_answer_num;
		aboard[width*i+j].letter = j-start_at;
		if (board[i*width+j] == 'b') border_squares++;
		if (board[i*width+j] == 'x') oob_squares++;
		if (board[i*width+j] >= 'A' && board[i*width+j] <= 'Z') prefilled_squares++;
	    }
	    a_answers[a_answer_num].start_row = i;
	    a_answers[a_answer_num].start_col = start_at;
	    a_answers[a_answer_num].len = j-start_at;
	    max_len = (j-start_at > max_len) ? j - start_at : max_len;
	    DPRINT ("Across answer %d starts at %d,%d and is %d letters long\n", a_answer_num, i, start_at, j-start_at);
	    if (border_squares+prefilled_squares == j-start_at) {
		DPRINT ("*** border answer ***\n");
		a_answers[a_answer_num].border_answer = 1;
	    } else {
		a_answers[a_answer_num].border_answer = 0;
	    }
	    if (oob_squares > 0 && border_squares+oob_squares+prefilled_squares == j-start_at) {
		DPRINT ("*** oob answer - ignore ***\n");
		for (k = 0; k < j-start_at; k++) {
		    aboard[width*i+start_at+k].answer = -1;
		}
	    } else if (oob_squares > 0) {
		printf ("*** oob answer - ignore ***\n");
		for (k = 0; k < j-start_at; k++) {
		    aboard[width*i+start_at+k].answer = -1;
		}
	    } else {
		a_answer_num++;
		if (a_answer_num > MAX_ANSWERS/2) {
		    printf ("Too many across answers");
		    return -1;
		}
	    }
	    for (start_at = j; start_at < width; start_at++) {
		if (board[i*width+start_at] != EMPTY) break;
	    }
	}
    }
    for (i = 0; i < width; i++) {
	start_at = 0;
	while (start_at < height) {

	    // Skip blanks at beginning of line
	    while (start_at < height && board[start_at*width+i] == EMPTY) start_at++;
	    if (start_at == height) break;

	    border_squares = oob_squares = prefilled_squares = 0;
	    for (j = start_at; j < height; j++) {
		if (board[j*width+i] == EMPTY) break;
		dboard[width*j+i].answer = d_answer_num;
		dboard[width*j+i].letter = j-start_at;
		if (board[j*width+i] == 'b') border_squares++;
		if (board[j*width+i] == 'x') oob_squares++;
		if (board[j*width+i] >= 'A' && board[j*width+i] <= 'Z') prefilled_squares++;
	    }
	    d_answers[d_answer_num].start_row = start_at;
	    d_answers[d_answer_num].start_col = i;
	    d_answers[d_answer_num].len = j-start_at;
	    max_len = (j-start_at > max_len) ? j - start_at : max_len;
	    DPRINT ("Down answer %d starts at %d,%d and is %d letters long\n", d_answer_num, start_at, i, j-start_at);
	    if (border_squares+prefilled_squares == j-start_at) {
		DPRINT ("*** border answer ***\n");
		d_answers[d_answer_num].border_answer = 1;
	    } else {
		d_answers[d_answer_num].border_answer = 0;
	    }
	    if (oob_squares > 0 && border_squares+oob_squares+prefilled_squares == j-start_at) {
		DPRINT ("*** oob answer - ignore ***\n");
		for (k = 0; k < j-start_at; k++) {
		    dboard[width*(start_at+k)+i].answer = -1;
		}
	    } else if (oob_squares > 0) {
		DPRINT ("*** oob answer - ignore ***\n");
		for (k = 0; k < j-start_at; k++) {
		    dboard[width*(start_at+k)+i].answer = -1;
		}
	    } else {
		d_answer_num++;
		if (d_answer_num > MAX_ANSWERS/2) {
		    printf ("Too many down answers");
		    return -1;
		}
	    }
	    for (start_at = j; start_at < height; start_at++) {
		if (board[start_at*width+i] != EMPTY) break;
	    }
	}
    }

    for (i = 0; i < a_answer_num; i++) {
	for (j = 0; j < a_answers[i].len; j++) {
	    a_answers[i].crosses[j] = dboard[a_answers[i].start_row*width+a_answers[i].start_col+j];
	    DPRINT ("Cross for letter %d of across answer %d is down answer %d letter %d\n", 
		    j, i, a_answers[i].crosses[j].answer, a_answers[i].crosses[j].letter);
	}
    }

    for (i = 0; i < d_answer_num; i++) {
	for (j = 0; j < d_answers[i].len; j++) {
	    d_answers[i].crosses[j] = aboard[(d_answers[i].start_row+j)*width+d_answers[i].start_col];
	    DPRINT ("Cross for letter %d of down answer %d is across answer %d letter %d\n", 
		    j, i, d_answers[i].crosses[j].answer, d_answers[i].crosses[j].letter);
	}
    }

    // replace any border squares
    if (replace_border_squares) {
	for (i = 0; i < height*width; i++) {
	    if (board[i] == 'b') board[i] = 0;
	}
    }

    return 0;
}

int
read_board_file (char* filename, int* pheight, int* pwidth, u_char** ppgrid)
{
  FILE* fp;
  int i, j;
  u_char ch;

  u_char* board;

  fp = fopen (filename, "r");
  if (fscanf (fp, "%d %d\n", pheight, pwidth) != 2) {
    fprintf (stderr, "Cannot read board height/width");
    return -1;
  }
  board = malloc (*pheight * *pwidth * sizeof(u_char));
  if (!board) {
      fprintf (stderr, "Cannot allocate board\n");
      return -1;
  }
  for (i = 0; i < *pheight; i++) {
    for (j = 0; j < *pwidth; j++) {
      ch = fgetc (fp);
      if (ch == '_') {
	board[i*(*pwidth)+j] = 0;
      } else if (ch == '@') {
	board[i*(*pwidth)+j] = EMPTY;
	blocks++;
      } else if (ch >= 'A' && ch < 'A'+ALPHABET) {
	board[i*(*pwidth)+j] = ch;
      } else if (ch == 'b' || ch == 'x') {  // For a partitioned board
	board[i*(*pwidth)+j] = ch;
      } else {
	  fprintf (stderr, "Invalid character %c in board\n", ch);
	  return -1;
      }
    }
    ch = fgetc (fp);
    if (i == *pheight-1 && feof(fp)) continue;
    if (ch != '\n') {
	fprintf (stderr, "Line %d too long in board: char %c\n", i, ch);
	return -1;
    }
  }

  fclose (fp);
  *ppgrid = board;
  return 0;
}
