#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <semaphore.h>
#include <pthread.h>
#include <assert.h>

#define MAX 75

int make_partition (int x, int y, char grid[16][15])
{
    int cnt, i;

    if (grid[y][x] != 'x') return 0;

    grid[y][x] = '_';
    cnt = 1;

    for (i = x+1; i < 15 && grid[y][i] != '@'; i++) cnt += make_partition(i, y, grid);
    for (i = x-1; i >= 0 && grid[y][i] != '@'; i--) cnt += make_partition(i, y, grid);
    for (i = y+1; i < 16 && grid[i][x] != '@'; i++) cnt += make_partition(x, i, grid);
    for (i = y-1; i >= 0 && grid[i][x] != '@'; i--) cnt += make_partition(x, i, grid);
    return cnt;
}

int make_partition_rev (int x, int y, char grid[16][15])
{
    int cnt, i;

    if (grid[y][x] != '_') return 0;

    grid[y][x] = 'x';
    cnt = 1;

    for (i = x+1; i < 15 && grid[y][i] != '@'; i++) cnt += make_partition_rev(i, y, grid);
    for (i = x-1; i >= 0 && grid[y][i] != '@'; i--) cnt += make_partition_rev(i, y, grid);
    for (i = y+1; i < 16 && grid[i][x] != '@'; i++) cnt += make_partition_rev(x, i, grid);
    for (i = y-1; i >= 0 && grid[i][x] != '@'; i--) cnt += make_partition_rev(x, i, grid);
    return cnt;
}

static int
make_unknown (char grid[16][15]) 
{
    int i, j, open_squares = 0;

    for (i = 0; i < 16; i++) {
	for (j = 0; j < 15; j++) {
	    if (grid[i][j] == '_') {
		open_squares++;
		grid[i][j] = 'x';
	    }
	}
    }
    return open_squares;
}

static int
elim_border (char grid[16][15]) 
{
    int i, j, open_squares = 0;

    for (i = 0; i < 16; i++) {
	for (j = 0; j < 15; j++) {
	    if (grid[i][j] == 'b') {
		open_squares++;
		grid[i][j] = '_';
	    } else if (grid[i][j] == '_') {
		open_squares++;
	    }
	}
    }
    return open_squares;
}

int split_partition_top (char grid[16][15])
{
    int i, x;

    for (x = 0; x < 15; x++) {
	if (grid[5][x] == '_' && grid[10][x] == '_') {
	    for (i = 10; i < 16 && grid[i][x] != '@'; i++) grid[i][x] = 'b';
	    for (i = 5; i >= 0 && grid[i][x] != '@'; i--) grid[i][x] = 'b';
	}
    }

    make_unknown(grid);
    return make_partition(0,0,grid);
}

int split_partition_bottom (char grid[16][15])
{
    int i, x;

    for (x = 0; x < 15; x++) {
	if (grid[5][x] == '_' && grid[10][x] == '_') {
	    for (i = 10; i < 16 && grid[i][x] != '@'; i++) grid[i][x] = 'b';
	    for (i = 5; i >= 0 && grid[i][x] != '@'; i--) grid[i][x] = 'b';
	}
    }

    make_unknown(grid);
    return make_partition(0,15,grid);
}

int 
isblock (int y, int x, char grid[16][15])
{
    return (grid[y][x] == '@');
}

int
block (int y, int x, char grid[16][15])
{
    if (y == -1 || y == 16) return 0; // OK to put a block "on the edge"
    if (x == -1 || x == 15) return 0;

    if (isblock(y,x,grid)) return 0;

    //printf ("block at <%d,%d>\n", y, x);

    if (grid[y][x] != '_') {
	grid[y][x] = '@';
    } else {
	return -1;
    }

    // Check left
    if (x == 1) {
	if (block (y, 0, grid) < 0) return -1;
    } else if (x == 2) {
	if (block (y, 1, grid) < 0) return -1;
	if (block (y, 0, grid) < 0) return -1;
    } else if (x != 0) {
	if (isblock(y,x-2,grid)) {
	    if (block (y, x-1, grid) < 0) return -1;
	}
	if (isblock(y,x-3,grid)) {
	    if (block (y, x-1, grid) < 0) return -1;
	    if (block (y, x-2, grid) < 0) return -1;
	}
    }

    // Check right
    if (x == 13) {
	if (block (y, 14, grid) < 0) return -1;
    } else if (x == 12) {
	if (block (y, 13, grid) < 0) return -1;
	if (block (y, 14, grid) < 0) return -1;
    } else if (x != 14) {
	if (isblock(y,x+2,grid)) {
	    if (block (y, x+1, grid) < 0) return -1;
	}
	if (isblock(y,x+3,grid)) {
	    if (block (y, x+1, grid) < 0) return -1;
	    if (block (y, x+2, grid) < 0) return -1;
	}
    }

    // Check top
    if (y == 1) {
	if (block (0, x, grid) < 0) return -1;
    } else if (y == 2) {
	if (block (1, x, grid) < 0) return -1;
	if (block (0, x, grid) < 0) return -1;
    } else if (y != 0) {
	if (isblock(y-2,x, grid)) {
	    if (block (y-1, x, grid) < 0) return -1;
	}
	if (isblock(y-3,x,grid)) {
	    if (block (y-1, x, grid) < 0) return -1;
	    if (block (y-2, x, grid) < 0) return -1;
	}
    }
	
    // Check bottom
    if (y == 14) {
	if (block (15, x, grid) < 0) return -1;
    } else if (y == 13) {
	if (block (14, x, grid) < 0) return -1;
	if (block (15, x, grid) < 0) return -1;
    } else if (y != 15) {
	if (isblock(y+2,x,grid)) {
	    if (block (y+1, x, grid) < 0) return -1;
	}
	if (isblock(y+3,x,grid)) {
	    if (block (y+1, x, grid) < 0) return -1;
	    if (block (y+2, x, grid) < 0) return -1;
	}
    }

    // Symmetry
    return block (15-y, 14-x, grid);
}

int 
isopensquare (int y, int x, char grid[16][15])
{
    return (grid[y][x] == '_');
}


int
opensquare (int y, int x, char grid[16][15])
{
    assert (x >= 0 && y >= 0 && x < 15 && y < 16);
    if (isopensquare(y,x,grid)) return 0;

    if (grid[y][x] != '@') {
	grid[y][x] = '_';
    } else {
	return -1;
    }
    
    // Symmetry
    return opensquare (15-y, 14-x, grid);
}

static void
print_board (char* filename, char wgrid[16][15])
{
    FILE* file;
    int i, j;
    
    file = fopen(filename, "w");
    if (file == NULL) {
	perror ("fopen output board\n");
	exit (0);
    }

    fprintf (file, "16 15\n");
    for (i = 0; i < 16; i++) {
	for (j = 0; j < 15; j++) {
	    fprintf (file, "%c", wgrid[i][j]);
	}
	fprintf (file, "\n");
    }
    fclose (file);
}

int
try_penalty (char* filename, char* partition, int timeout, int trypen)
{
    char cmd[256], line[256], part[256];
    FILE* file;
    int rc, newpen, penalty = 999;

    printf ("try penalty %d\n", trypen);
    if (partition) {
	sprintf (part, "-p %s", partition);
    } else {
	part[0] = '\0';
    }
    if (trypen >= 0) {
	sprintf (cmd, "timelimit -s 9 -t %d ./placer -b %s %s -w wordlists/master.txt -v 25 -m 1 -s -y %d > /tmp/solution.343phase4", 
		 timeout, filename, part, trypen); 
    } else {
	sprintf (cmd, "timelimit -s 9 -t %d ./placer -b %s %s -w wordlists/master.txt -v 25 -m 1 -s > /tmp/solution.343phase4", 
		 timeout, filename, part); 
    }

    rc = system (cmd);
    if (WEXITSTATUS(rc) == 137) return -2; // timeout
    rc = system("grep \"\\-SOLUTION\\-\" /tmp/solution.343phase4");
    if (rc != 256) {
	file = fopen("/tmp/solution.343phase4", "r");
	if (file == NULL) return -3; // error
	while (!feof(file)) {
	    if (fgets (line, sizeof(line), file)) {
		if (!strncmp(line, "penalty: ", 9)) {
		    newpen = atoi(line+9);
		    if (newpen < penalty) {
			penalty = newpen;
		    }
		}
	    }
	}
	fclose(file);
	return penalty;
    } else {
	return -1; // No match
    }
}

int
refine (char* filename, char* partition, int timeout)
{
    int penalty, low_pen, high_pen, try_pen;

    penalty = try_penalty (filename, partition, timeout, MAX);
    if (penalty < 0) return penalty;
    rename ("/tmp/solution.343phase4", "/tmp/solution.343phase4.sav");
    
    low_pen = -1;
    high_pen = penalty;
    while (high_pen - low_pen > 1) {
	try_pen = (low_pen + high_pen) / 2;
	penalty = try_penalty(filename, partition, timeout, try_pen);
	if (penalty < 0) {
	    low_pen = try_pen;
	} else {
	    rename ("/tmp/solution.343phase4", "/tmp/solution.343phase4.sav");
	    high_pen = penalty;
	}
    }
    return high_pen;
}

int
read_solution (char* filename, char grid[16][15])
{
    FILE* file;
    char line[256];
    int i, j;

    file = fopen(filename, "r");
    if (file == NULL) return -1;

    while (!feof(file)) {
	if (fgets (line, sizeof(line), file)) {
	    if (!strncmp(line, "weighted", 8)) {  
		for (i = 0; i < 17; i++) {
		    if (fgets (line, sizeof(line), file)) {
			if (i > 0) {
			    for (j = 0; j < 15; j++) {
				if (line[j] >= 'A' && line[j] <= 'Z') {
				    if (grid[i-1][j] != line[j]) {
					grid[i-1][j] = line[j];
				    }
				}
			    }
			}
		    }
		}
		fclose(file);
		return 0;
	    }
	}
    }
    fclose(file);
    return -1;
}
    
int main (int argc, char* argv[])
{
    FILE * file;
    char line[256], filename[256];
    char grid[16][15], wgrid[16][15], bgrid[16][15];
    int i, j, cnt, rc, open_squares, timeout = 1800, penalty;

    if (argc < 2) {
	fprintf (stdout, "343phase4 <qboard> [timeout]\n");
	exit (0);
    }
    if (argc == 3) {
	timeout = atoi(argv[2]);
    }

    // read board
    file = fopen (argv[1], "r");
    if (file == NULL) {
	perror("fopen");
	return -1;
    }
    i = 0;
    while (!feof(file)) {
	if (fgets (line, sizeof(line), file)) {
	    if (i > 0) {
		for (j = 0; j < 15; j++) {
		    grid[i-1][j] = line[j];
		}
	    }
	    i = i+1;
	}
    }
    fclose (file);

    // First see if we can place any squares not reachable from top or bottom
    memcpy (wgrid, grid, sizeof(grid));
    open_squares = elim_border (wgrid);
    cnt = make_partition_rev (0,0,wgrid);
    cnt += make_partition_rev (0,15,wgrid);
    if (open_squares == cnt) {
	printf ("No partitioned squares\n"); 
    } else {
	printf ("Partitioned squares %d %d\n", cnt, open_squares);

	print_board ("/tmp/board.343phase4", wgrid);
	rc = refine ("/tmp/board.343phase4", NULL, timeout);
	if (rc >= 0) {
	    printf ("final penalty: %d\n", rc);
	    read_solution("/tmp/solution.343phase4.sav", grid);
	}
    }

    // First try to see if we can find any placement - do top partition first
    memcpy (wgrid, grid, sizeof(grid));
    cnt = 0;
    for (i = 0; i < 15; i++) {
	if (wgrid[15][i] == '_') {
	    cnt = make_partition_rev(i,15, wgrid);
	    break;
	}
    }
    if (cnt == 0) {
	printf ("Cannot make top partition?\n");
	exit (0);
    }
    print_board ("/tmp/board.343phase4t", wgrid);
    penalty = try_penalty ("/tmp/board.343phase4t", NULL, timeout, MAX);
    printf ("top penalty is %d\n", penalty);
    if (penalty < 0) return penalty;

    // Now do bottom solution - building off of top partition
    rename ("/tmp/solution.343phase4", "/tmp/solution.343phase4.top");
    memcpy (bgrid, grid, sizeof(grid));
    cnt = 0;
    for (i = 0; i < 15; i++) {
	if (bgrid[0][i] == '_') {
	    cnt = make_partition_rev(i,0, bgrid);
	    break;
	}
    }
    if (cnt == 0) {
	printf ("Cannot make bottom partition?\n");
	exit (0);
    }
    print_board ("/tmp/board.343phase4b", bgrid);
    penalty = try_penalty ("/tmp/board.343phase4b", "/tmp/solution.343phase4.top", timeout, MAX);
    printf ("bottom penalty is %d\n", penalty);
    rename ("/tmp/solution.343phase4", "/tmp/solution.343phase4.bottom");
    if (penalty < 0) return penalty;

    // OK first refine the top
    rc = refine ("/tmp/board.343phase4t", "/tmp/solution.343phase4.bottom", timeout);
    if (rc < 0) return rc;
    printf ("best top penalty: %d\n", rc);
    read_solution("/tmp/solution.343phase4.sav", bgrid);
    print_board ("/tmp/board.343phase4tb", bgrid);

    // then the bottom
    rc = refine ("/tmp/board.343phase4tb", "/tmp/solution.343phase4.bottom", timeout);
    if (rc < 0) return rc;
    printf ("best top overall penalty: %d\n", rc);
    sprintf (filename, "%s-top", argv[1]);
    filename[4] = '4'; // hack
    rename ("/tmp/solution.343phase4.sav", filename);

    // Not do it again, but bottom first
    rc = refine ("/tmp/board.343phase4b", "/tmp/solution.343phase4.bottom", timeout);
    if (rc < 0) return rc;
    printf ("best bottom penalty: %d\n", rc);
    read_solution("/tmp/solution.343phase4.sav", wgrid);
    print_board ("/tmp/board.343phase4bt", wgrid);

    // then the top
    rc = refine ("/tmp/board.343phase4bt", "/tmp/solution.343phase4.bottom", timeout);
    if (rc < 0) return rc;
    printf ("best bottom overall penalty: %d\n", rc);
    sprintf (filename, "%s-bottom", argv[1]);
    filename[4] = '4'; // hack
    rename ("/tmp/solution.343phase4.sav", filename);

    return 0;
}
